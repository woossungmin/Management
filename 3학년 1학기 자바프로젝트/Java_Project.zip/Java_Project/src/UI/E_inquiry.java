package UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class E_inquiry {
	private JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					E_inquiry window = new E_inquiry();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public E_inquiry() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(300, 120, 718, 512);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 704, 99);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 99, 703, 317);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(277, 14, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JLabel lblNewLabel_1 = new JLabel("사번 : ");
		lblNewLabel_1.setBounds(88, 66, 52, 15);
		panel.add(lblNewLabel_1);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(277, 14, 146, 23);
		panel.add(progressBar);
		
		textField = new JTextField();
		textField.setBounds(152, 66, 281, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JTable table = new JTable();
		table.getTableHeader().setReorderingAllowed(false); 
		table.getTableHeader().setResizingAllowed(false);
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //테이블 마우스 클릭 이벤트
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				 
				click_mem.emp = (String) table.getModel().getValueAt(row,1);
				click_mem.name = (String) table.getModel().getValueAt(row,2);
				
				E_family ef = new E_family(click_mem.emp,click_mem.name);
			}
		});
		scrollPane.setBounds(2, 0, 702, 317);
		panel_1.add(scrollPane);
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"구분", "사번", "이름", "부서", "직위", "성별", "전화번호","생년월일"
			}	
		));
		scrollPane.setViewportView(table);
		table.getColumn("구분").setPreferredWidth(20);
		table.getColumn("사번").setPreferredWidth(40);
		table.getColumn("이름").setPreferredWidth(40);
		table.getColumn("부서").setPreferredWidth(40);
		table.getColumn("직위").setPreferredWidth(40);
		table.getColumn("성별").setPreferredWidth(40);
		table.getColumn("전화번호").setPreferredWidth(40);
		table.getColumn("생년월일").setPreferredWidth(40);
		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer(); //테이블 밑에 사용 튜플값들 가운데 정렬
	    dtcr.setHorizontalAlignment(SwingConstants.CENTER);
	    TableColumnModel tcm = table.getColumnModel();
	    for(int i = 0; i < tcm.getColumnCount(); i++) {
	    	tcm.getColumn(i).setCellRenderer(dtcr);
	    }
	    
	    //버튼
	    JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Login lo = new Login();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
	    
		JButton btnNewButton_1 = new JButton("조회");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				model.setRowCount(0);
				DB_Connection db = new DB_Connection();
				Connection conn = db.getConn();
				String tx = textField.getText();
				PreparedStatement pstmt = null;
			 	ResultSet rs = null;
			 	String sql = "select E.emp_number,names,department,position,gender,E.phone,birth "
			 			+ "from person P,employee E "
			 			+ "where P.phone = E.phone and E.emp_number like '%'+?+'%'";
			 	try {
					pstmt = conn.prepareStatement(sql);		
					pstmt.setString(1,tx);
					rs = pstmt.executeQuery();
					int number = 0;
					String employee_number = "";
					String name = "";
					String department = "";
					String position = "";
					String gender = "";
					String phone = "";
					String birth = "";
					while(rs.next())
					{
						number++;
						String num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
						employee_number = rs.getString(1);
						name = rs.getString(2);
						department = rs.getString(3);
						position = rs.getString(4);
						gender = rs.getString(5);
						phone = rs.getString(6);
						birth = rs.getString(7);
						String[] row = { num_1,employee_number,name,department,position,gender,phone,birth};
						model.addRow(row);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}	
			}
		});
		btnNewButton_1.setBounds(445, 55, 87, 18);
		panel.add(btnNewButton_1);
		
		// 메서드로 넘기는거 실패
		JButton btnNewButton_1_1 = new JButton("전체 조회");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_Connection db = new DB_Connection();
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				Connection conn = db.getConn();
				PreparedStatement pstmt = null;
			 	ResultSet rs = null;
			 	String sql = "select E.emp_number,P.names,E.position,E.department,P.gender,E.phone,P.birth"
			 			+ " from employee E, person P "
			 			+ "where E.phone = E.phone and E.phone = P.phone";
			 	try {
					pstmt = conn.prepareStatement(sql);		
					rs = pstmt.executeQuery();
					int number = 0;
					String employee_number = "";
					String name = "";
					String department = "";
					String position = "";
					String gender = "";
					String phone = "";
					String birth = "";
					String num_1;
					String[] row = null;
					model.setRowCount(0);
					while(rs.next())
					{
						number++;
						num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
						employee_number = rs.getString(1);
						name = rs.getString(2);
						department = rs.getString(4);
						position = rs.getString(3);
						gender = rs.getString(5);
						phone = rs.getString(6);
						birth = rs.getString(7);
						row = new String[]{ num_1,employee_number,name,department,position,gender,phone,birth};
						model.addRow(row);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}	
			}
		});
		btnNewButton_1_1.setBounds(445, 74, 87, 18);
		panel.add(btnNewButton_1_1);
		
		JButton btnNewButton_4 = new JButton("등록");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				E_Regist er = new E_Regist();
			}
		});
		btnNewButton_4.setBounds(544, 53, 62, 40);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_4_1 = new JButton("수정");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				E_Modify em = new E_Modify();
			}
		});
		btnNewButton_4_1.setBounds(609, 53, 62, 40);
		panel.add(btnNewButton_4_1);
		
		JButton btnNewButton_3 = new JButton("급여 관리");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				S_inquiry Si = new S_inquiry();
			}
		});
		btnNewButton_3.setBounds(600, 425, 95, 39);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_2 = new JButton("초기화");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				model.setRowCount(0);
			}
		});
		btnNewButton_2.setBounds(510, 433, 78, 23);
		frame.getContentPane().add(btnNewButton_2);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setContentAreaFilled(false);
		
		
		
		
	}
}
