package UI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Membership {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JLabel lblNewLabel_1;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Membership window = new Membership();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Membership() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(420, 150, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 436, 413);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(146, 24, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(146, 24, 146, 23);
		panel.add(progressBar);
		
		textField = new JTextField();
		textField.setBounds(89, 128, 257, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(89, 178, 257, 21);
		panel.add(textField_1);
		textField_1.setEnabled(false);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(89, 228, 257, 21);
		panel.add(textField_2);
		textField_2.setEnabled(false);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(89, 278, 257, 21);
		panel.add(textField_3);
		
		lblNewLabel_1 = new JLabel("전화번호 :");
		lblNewLabel_1.setBounds(22, 128, 62, 15);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("확인");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField.getText();
				String tx_3 = textField.getText();
				DB_Connection db = new DB_Connection();
				String[] sql_result = db.findphone(tx);
				if(sql_result == null)
				{
					Message ms = new Message("회원가입 불가");
				}
				else {
					textField_1.setText(sql_result[0]);
					textField_2.setText(sql_result[1]);	
				}
			}
		});
		btnNewButton.setBounds(358, 126, 66, 24);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel_1_1 = new JLabel("사번 : ");
		lblNewLabel_1_1.setBounds(22, 178, 62, 15);
		panel.add(lblNewLabel_1_1);
		
		
		JLabel lblNewLabel_1_2 = new JLabel("이름 :");
		lblNewLabel_1_2.setBounds(22, 228, 62, 15);
		panel.add(lblNewLabel_1_2);
		
		
		JLabel lblNewLabel_1_2_1 = new JLabel("비밀번호 :");
		lblNewLabel_1_2_1.setBounds(22, 278, 62, 15);
		panel.add(lblNewLabel_1_2_1);
		
		JButton btnNewButton_1 = new JButton("회원가입");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx_3 = textField_3.getText();
				String tx_2 = textField_2.getText();
				String tx_1 = textField_1.getText();
				DB_Connection db = new DB_Connection();
				
				int result = db.insert_manager(tx_1,tx_2,tx_3);
				if(result == 1)
				{
					Message ns = new Message("회원가입 실패");
					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
				}
				else {
					Message ms = new Message("회원가입 완료");
					frame.dispose();
					Login lo = new Login();	
				}
			}
		});
		btnNewButton_1.setBounds(130, 334, 178, 32);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Login lo = new Login();
			}
		});
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton_2.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton_2);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setContentAreaFilled(false);
		
	}
}
