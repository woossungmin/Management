package UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JTextField;

public class Login {
	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	public void initialize() {
		frame = new JFrame();
		frame.setBounds(420, 150, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 436, 413);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(146, 24, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(146, 24, 146, 23);
		panel.add(progressBar);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
		
		textField = new JTextField();
		textField.setBounds(100, 150, 257, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JPasswordField pt = new JPasswordField();
		pt.setColumns(10);
		pt.setBounds(100, 210, 257, 21);		
		panel.add(pt); 
		JLabel lblNewLabel_1 = new JLabel("사번 : ");
		lblNewLabel_1.setBounds(33, 150, 66, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("비밀번호 : ");
		lblNewLabel_1_1.setBounds(33, 210, 66, 15);
		panel.add(lblNewLabel_1_1);
		
		JButton btnNewButton_1 = new JButton("로그인");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_Connection db = new DB_Connection();
				db.getConn();
				String tx = textField.getText();
				String tx_1 = pt.getText();
				int res = db.login(tx,tx_1);
				if(res == 1)
				{
					Message ms = new Message("로그인 성공");
					frame.dispose();
					E_inquiry ei = new E_inquiry();
				}
				else
				{
					Message ms = new Message("로그인 실패");
					textField.setText(""); //텍스트 필드 초기화
					pt.setText(""); //텍스트 필드 초기화
				}
			}
		});
		btnNewButton_1.setBounds(100, 270, 257, 32);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("비밀번호 찾기");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				FindPassword ps = new FindPassword();
			}
		});
		btnNewButton_2.setBounds(218, 324, 117, 23);
		panel.add(btnNewButton_2);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setContentAreaFilled(false);
		
		JButton btnNewButton_2_1 = new JButton("회원가입");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Membership mb = new Membership();
			}
		});
		btnNewButton_2_1.setBounds(120, 324, 86, 23);
		panel.add(btnNewButton_2_1);
		btnNewButton_2_1.setBorderPainted(false);
		btnNewButton_2_1.setContentAreaFilled(false);
		
		JLabel lblNewLabel_2_1 = new JLabel("ㅣ");
		lblNewLabel_2_1.setBounds(206, 328, 21, 15);
		panel.add(lblNewLabel_2_1);
		
	}


}
