package UI;

public class click_mem {
	static String name;
	static String emp;
}
