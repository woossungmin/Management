package UI;

import java.sql.*;

import javax.management.relation.Role;
import javax.swing.table.DefaultTableModel;

import com.microsoft.sqlserver.jdbc.SQLServerException;

public class DB_Connection {	
	Connection conn;
	public DB_Connection(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}  
        String connectionUrl =
                "jdbc:sqlserver://localhost:1433;"
        				+ "encrypt=true;"
        				+ "integratedSecurity=true;"
                        + "database=JAVA;"
                        + "trustServerCertificate=true;"
                        + "user=sungmin;"
                        + "password=1234;";
        try {
        	conn = DriverManager.getConnection(connectionUrl);
        }
        catch (SQLException e) {
        }  
	}
	 public Connection getConn() {
		 return conn;
	 }
	 
	 public int login(String tx,String tx_1) //로그인 sql문
		{
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select emp_number,pw from manager where emp_number = ? and pw = ?"; //관리자 테이블에 입력한 사번이랑 비밀번호가 있는지 확인
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				pstmt.setString(2,tx_1);
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}		
			return 0;
		}
	 
	 public String[] findphone(String tx) //membership 클래스에 전화번호로 검색하여 사번과 이름 출력
	 {
		 PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select emp_number,names from employee,person where employee.phone = person.phone and employee.phone = ? and employee.department like '인사%'";
			//회원가입 시 전화번호를 입력하여 사번이랑 이름을 가져온다. 단, 일하고 있는 부서가 인사팀으로 되어있을 경우에만 회원가입 가능
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					String emp_number = rs.getString(1);
					String name = rs.getString(2);
					String[] sql_result = {emp_number,name};
					return sql_result;
				}
				else {
				}
			} catch (SQLException e) {
			}
			return null;		
	 }
	 
		
	 public int insert_manager(String emp_number, String name, String pw) // 회원가입 sql
	 {
		 PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "insert into manager(emp_number,names,pw) values(?,?,?)"; //입력한 사번, 이름, 비밀번호로 회원가입을 할 수 있다.
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,emp_number);
				pstmt.setString(2, name);
				pstmt.setString(3,pw);
				int result = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				return 1;
			} 
			return 0;
	 }
	 
	 public String find_pw(String tx, String tx_1) //비밀번호 찾기 sql
	 {
		 PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select pw "
					+ "from employee E,person P,manager M "
					+ "where M.emp_number = E.emp_number and E.emp_number = ?  and E.phone = ?";
			//사람 테이블과 관리자 테이블을 조인하여 사번과 전화번호를 입력하면 비밀번호를 알려준다.
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				pstmt.setString(2,tx_1);
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					String pw = rs.getString(1);
					return pw;
				}
				else {
				}
			} catch (SQLException e) {

			}		
			return null;
	 }
	 
	 public int E_regist(String tx, String tx1, String tx2, String tx3, String tx4, String tx5, String tx6) //사원등록
	 {
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 	String sql = "insert into person(phone,names,gender,birth) values(?,?,?,?)";
		 	String sql1 = "insert into employee(emp_number,department,position,phone) values(?,?,?,?)";
		 	
		 	//사람과 사원으로 테이블을 분리해놨기때문에 사원 테이블에도 넣어주고 , 사람테이블에도 넣어준다. 
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx5);
				pstmt.setString(2,tx);
				pstmt.setString(3,tx4);
				pstmt.setString(4,tx6);
				int result = pstmt.executeUpdate();
				pstmt = conn.prepareStatement(sql1);
				pstmt.setString(1,tx1);
				pstmt.setString(2,tx2);
				pstmt.setString(3,tx3);
				pstmt.setString(4,tx5);
				
				result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 return 0;
	 }
	 
	 public String[] find_emp(String tx) //사원조회
	 {
		 PreparedStatement pstmt = null;
			ResultSet rs = null;
			String sql = "select emp_number,names,department,position,gender,E.phone,birth from employee E, person P where E.phone = P.phone and emp_number = ?";
			//사원테이블과 사람테이블을 조인하여 전화번호와 사번으로 해당 사원에 정보를 찾는다.
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					String emp_number = rs.getString(1);
					String name = rs.getString(2);
					String department = rs.getString(3);
					String position = rs.getString(4);
					String gender = rs.getString(5);
					String phone = rs.getString(6);
					String birth = rs.getString(7);
					
					String[] sql_result = {emp_number,name,department,position,gender,phone,birth};
					return sql_result;
				}
				else {
				}
			} catch (SQLException e) {
			}
			return null;		
	 }
	 
	 public int E_update(String tx, String tx1, String tx2, String tx3, String tx4, String tx5, String tx6, String tx7) //사원 수정
	 {
		 PreparedStatement pstmt = null;
		 	ResultSet rs = null;
		 	
		 	String sql = "update person set names = ?, gender = ?, birth = ?, phone = ? where phone = ?";
		 	//사원에 전화번호를 입력하여 수정한다.
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx1);
				pstmt.setString(2, tx4);
				pstmt.setString(3,tx6);
				pstmt.setString(4,tx5);
				pstmt.setString(5, tx7); //수정되기 전 전화번호
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
				}
				else {
				}
			} catch (SQLException e) {
			}
		 	
		 	String sql1 = "update employee set emp_number = ?, department = ?, position = ? where emp_number = ?";
		 	//사원에 저화번호를 입력하여 수정한다.
		 	try {
				pstmt = conn.prepareStatement(sql1);
				pstmt.setString(1,tx);
				pstmt.setString(2, tx2);
				pstmt.setString(3,tx3);
				pstmt.setString(4, tx);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 	
		 	return 0;
	 }
	 
	 public int E_delete(String tx) //사원삭제
	 {
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 	String sql = "delete from person where phone = ?";
		 	//사원에 전화번호로 사람테이블에 정보삭제
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 return 0;
	 }
	 
	 public int F_regist(String tx, String tx1,String tx2, String tx3, String tx4, String tx5, String emp)  //가족정보 등록
	 {
		 PreparedStatement pstmt = null;
		 	ResultSet rs = null;
		 	String sql = "insert into person(phone,names,gender,birth) values(?,?,?,?)";
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx5);
				pstmt.setString(2, tx2);
				pstmt.setString(3,tx3);
				pstmt.setString(4,tx4);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
				}
				else {
					
				}
			} catch (SQLException e) {
			}
		 	String sql1 = "insert into family(phone,relation,job,emp_number) values(?,?,?,?)";
		 	try {
				pstmt = conn.prepareStatement(sql1);
				pstmt.setString(1,tx5);
				pstmt.setString(2, tx);
				pstmt.setString(3,tx1);
				pstmt.setString(4,emp);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 	return 0;
	 }
	 
	 public String[] f_inquiry(String tx) //가족정보 조회
	 {
		 PreparedStatement pstmt = null;
		 	ResultSet rs = null;
		 	String sql = "select relation, job, names, gender, birth, P.phone "
		 			+ "from person P,family F "
		 			+ "where P.phone = F.phone and F.emp_number = ?"; 
		 	try {
				pstmt = conn.prepareStatement(sql);		
				pstmt.setString(1,tx);
				rs = pstmt.executeQuery();
				int number = 0;
				String relation = "";
				String job = "";
				String names = "";
				String gender = "";
				String birth = "";
				String phone = "";
				while(rs.next())
				{
					number++;
					String num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
					relation = rs.getString(1);
					job = rs.getString(2);
					names = rs.getString(3);
					gender = rs.getString(4);
					birth = rs.getString(5);
					phone = rs.getString(6);
					String[] row = { num_1,relation,job,names,gender,birth,phone};
					System.out.println(row);
					return row;
				}
				
				
			} catch (SQLException e) {
			}	
		 	return null;
	 }
	 
	 public int f_update(String tx, String tx1, String tx2, String tx3, String tx4, String tx5,String tx6) //가족정보 업데이트
	 {
		 PreparedStatement pstmt = null;
		 	ResultSet rs = null;
		 	String sql = "update person set names = ?, gender = ?, birth = ?, phone = ? where phone = ?";
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx2);
				pstmt.setString(2, tx3);
				pstmt.setString(3,tx4);
				pstmt.setString(4,tx5);
				pstmt.setString(5,tx6);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
				}
				else {
				}
			} catch (SQLException e) {
			}
		 	String sql1 = "update family set relation = ?, job = ? where phone = ?";
		 	try {
				pstmt = conn.prepareStatement(sql1);
				pstmt.setString(1,tx);
				pstmt.setString(2, tx1);
				pstmt.setString(3,tx5);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 	return 0;
		 		
	 }
	 
	 public int f_delete(String tx) //가족 정보 삭제
	 {
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 	String sql = "delete from family where phone = ?";
		 	String sql1 = "delete from person where phone = ?";
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				int result = pstmt.executeUpdate();
				pstmt = conn.prepareStatement(sql1);
				pstmt.setString(1,tx);
				result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 return 0;
	 }
	 
	 public int S_Regist(String tx, String tx1, String tx2, String tx3, String tx4)
	 {
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 String sql = "insert into salary(emp_number,basics,bonus,overtime,other) values(?,?,?,?,?)";
		 try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				pstmt.setString(2, tx1);
				pstmt.setString(3,tx2);
				pstmt.setString(4,tx3);
				pstmt.setString(5,tx4);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 
		 return 0;
	 }
	 
	 public String[] S_emp_inquiry(String tx)
	 { 	
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 String sql = "select E.emp_number,names from employee E, person P where E.phone = P.phone and E.emp_number = ?";
		 try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					String emp_number = rs.getString(1);
					String name = rs.getString(2);
					
					String[] sql_result = {emp_number,name};
					return sql_result;
				}
				else {
				}
			} catch (SQLException e) {
			}
			 
			 return null;
	 }
	 

	 public String[] S_inquiry(String tx)
	 {
		 PreparedStatement pstmt = null;
		 	ResultSet rs = null;
		 	String sql = "select emp_number,names,basics,bonus,overtime,other "
		 			+ "from salary S,employee E,person P "
		 			+ "where S.emp_number = E.emp_number and E.phone = P.phone and  emp_number like %" + tx + "%";
		 
		 	try {
				pstmt = conn.prepareStatement(sql);		
				pstmt.setString(1,tx);
				rs = pstmt.executeQuery();
				int number = 0;
				String emp_number = "";
				String  name= "";
				String basics = "";
				String bonus = "";
				String overtime = "";
				String other = "";
				String sum = "";
				while(rs.next())
				{
					number++;
					String num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
					emp_number = rs.getString(1);
					name = rs.getString(2);
					basics = rs.getString(3);
					bonus = rs.getString(4);
					overtime = rs.getString(5);
					other = rs.getString(6);
					int basics1 = Integer.parseInt(basics);
					int bonus1 = Integer.parseInt(bonus);
					int overtime1 = Integer.parseInt(overtime);
					int other1 = Integer.parseInt(other);
					int sum1 = basics1 + bonus1 + overtime1 + other1;
					sum = Integer.toString(sum1);
					String[] row = { num_1,emp_number,name,basics,bonus,overtime,other,sum};
					return row;
				}
			} catch (SQLException e) {
			}	
		 	return null;
	 }
	 public String[] S_emp_inquiry1(String tx)
	 { 	
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 String sql = "select S.emp_number,P.names,basics,bonus,overtime,other "
		 		+ "from employee E, salary S, person P "
		 		+ "where S.emp_number = E.emp_number and E.phone = P.phone and E.emp_number = ?";
		 try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx);
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					String emp_number = rs.getString(1);
					String name = rs.getString(2);
					String basics = rs.getString(3);
					String bonuse = rs.getString(4);
					String overtime = rs.getString(5);
					String other = rs.getString(6);
					String[] sql_result = {emp_number,name,basics,bonuse,overtime,other};
					return sql_result;
				}
				else {
				}
			} catch (SQLException e) {
			}
			 
			 return null;
	 }
	 
	 public int S_update(String tx2, String tx3, String tx4, String tx5,String tx)
	 {
		 PreparedStatement pstmt = null;
		 	ResultSet rs = null;
		 	String sql = "update salary set basics = ?, bonus = ?, overtime = ?, other = ? where emp_number = ?";
		 	try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,tx2);
				pstmt.setString(2, tx3);
				pstmt.setString(3,tx4);
				pstmt.setString(4,tx5);
				pstmt.setString(5,tx);
				int result = pstmt.executeUpdate();
				if(result == 1)
				{
					return 1;
				}
				else {
				}
			} catch (SQLException e) {
			}
		 	return 0;
	 }
}
