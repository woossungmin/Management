package UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;

public class E_Modify {
	String tx7 = "";
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					E_Modify window = new E_Modify();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public E_Modify() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(420, 150, 450, 470);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 436, 433);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});

		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
		
		JTextField textField = new JTextField();
		textField.setBounds(100, 80, 257, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(100, 120, 257, 21);
		panel.add(textField_1);
		
		JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(100, 160, 257, 21);
		panel.add(textField_2);
		
		JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(100, 200, 257, 21);
		panel.add(textField_3);
		
		JTextField textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(100, 240, 257, 21);
		panel.add(textField_4);
		
		JTextField textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(100, 280, 257, 21);
		panel.add(textField_5);
		
		JTextField textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(100, 320, 257, 21);
		panel.add(textField_6);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(146, 24, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(146, 24, 146, 23);
		panel.add(progressBar);
		
		JLabel lblNewLabel_1 = new JLabel("사번 : ");
		lblNewLabel_1.setBounds(33, 80, 66, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("이름 : ");
		lblNewLabel_1_1.setBounds(33, 120, 66, 15);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("부서 : ");
		lblNewLabel_1_2.setBounds(33, 160, 66, 15);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("직급 : ");
		lblNewLabel_1_3.setBounds(33, 200, 66, 15);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("성별 : ");
		lblNewLabel_1_4.setBounds(33, 240, 66, 15);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("전화번호 : ");
		lblNewLabel_1_5.setBounds(33, 280, 66, 15);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("생년월일 : ");
		lblNewLabel_1_6.setBounds(33, 320, 66, 15);
		panel.add(lblNewLabel_1_6);
		
		JButton btnNewButton_2 = new JButton("초기화");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				textField_6.setText("");
				textField.setEnabled(true);
			}
		});
		btnNewButton_2.setBounds(120, 400, 86, 23);
		panel.add(btnNewButton_2);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setContentAreaFilled(false);
		

		JButton btnNewButton_4 = new JButton("조회");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField.getText();
				DB_Connection db = new DB_Connection();
				String[] row = db.find_emp(tx);
				Message ms = new Message("존재하는 사원입니다");
				textField.setText(row[0]);
				textField_1.setText(row[1]);
				textField_2.setText(row[2]);
				textField_3.setText(row[3]);
				textField_4.setText(row[4]);
				textField_5.setText(row[5]);
				textField_6.setText(row[6]);
				textField.setEnabled(false);
				tx7 = textField_5.getText(); //수정되기 전 전화번호
			}
		});
		btnNewButton_4.setBounds(358, 79, 66, 23);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_1 = new JButton("사원 수정");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField.getText();
				String tx1 = textField_1.getText();
				String tx2 = textField_2.getText();
				String tx3 = textField_3.getText();
				String tx4 = textField_4.getText();
				String tx5 = textField_5.getText();
				String tx6 = textField_6.getText();
				DB_Connection db = new DB_Connection();
				int result = db.E_update(tx,tx1,tx2,tx3,tx4,tx5,tx6,tx7);
				if(result == 1)
				{
					Message ms = new Message("수정 완료");
					frame.dispose();
				}
				else
				{
					Message ms = new Message("수정 실패");
				}
			}
		});
		btnNewButton_1.setBounds(100, 365, 257, 32);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2_1 = new JButton("삭제");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField_5.getText();
				DB_Connection db = new DB_Connection();
				int result = db.E_delete(tx);
				if(result == 1)
				{
					Message ms = new Message("삭제 완료");
					frame.dispose();
				}
				else
				{
					Message ms = new Message("삭제 실패");
				}
			}
		});
		btnNewButton_2_1.setContentAreaFilled(false);
		btnNewButton_2_1.setBorderPainted(false);
		btnNewButton_2_1.setBounds(253, 400, 86, 23);
		panel.add(btnNewButton_2_1);
		
		JButton btnNewButton_3 = new JButton("ㅣ");
		btnNewButton_3.setBounds(195, 400, 66, 23);
		panel.add(btnNewButton_3);
		btnNewButton_3.setContentAreaFilled(false);
		btnNewButton_3.setBorderPainted(false);
		
		
	}
}
