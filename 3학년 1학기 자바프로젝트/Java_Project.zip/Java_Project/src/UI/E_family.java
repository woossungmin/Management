package UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class E_family {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					E_family window = new E_family("","");
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public E_family(String emp, String name) {
		initialize(emp,name);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(String emp, String name) {
		frame = new JFrame();
		frame.setBounds(420, 150, 450, 440);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 436, 403);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(146, 24, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(146, 24, 146, 23);
		panel.add(progressBar);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});

		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
		
		JTable table = new JTable();
		JScrollPane scrollPane = new JScrollPane();
		table.getTableHeader().setReorderingAllowed(false); 
		table.getTableHeader().setResizingAllowed(false);
		
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //테이블 마우스 클릭 이벤트
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int col = table.getSelectedColumn();
				String relation = (String) table.getModel().getValueAt(row,1);
				String job = (String) table.getModel().getValueAt(row,2);
				String name = (String) table.getModel().getValueAt(row,3);
				String gender = (String) table.getModel().getValueAt(row,4);
				String birth = (String) table.getModel().getValueAt(row,5);
				String phone = (String) table.getModel().getValueAt(row,6);
				E_f_Modify ef = new E_f_Modify(relation,job,name,gender,birth,phone,emp,frame);
			}
		});
		scrollPane.setBounds(3, 120, 430, 150);
		panel.add(scrollPane);
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"구분","관계", "직업", "이름", "성별","생년월일","전화번호"
			}	
		));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel_1 = new JLabel("사번 : " + emp + "     " + name + "님의 가족");
		lblNewLabel_1.setBounds(110, 95, 244, 15);
		panel.add(lblNewLabel_1);
		table.getColumn("구분").setPreferredWidth(5);
		table.getColumn("관계").setPreferredWidth(10);
		table.getColumn("직업").setPreferredWidth(15);
		table.getColumn("이름").setPreferredWidth(10);
		table.getColumn("성별").setPreferredWidth(10);
		table.getColumn("생년월일").setPreferredWidth(40);
		table.getColumn("전화번호").setPreferredWidth(70);
		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer(); //테이블 밑에 사용 튜플값들 가운데 정렬
	    dtcr.setHorizontalAlignment(SwingConstants.CENTER);
	    TableColumnModel tcm = table.getColumnModel();
	    for(int i = 0; i < tcm.getColumnCount(); i++) {
	    	tcm.getColumn(i).setCellRenderer(dtcr);
	    }
	    //E_inquiry 전체조회와 같이 이차원배열로 넘기는거 실패
	    DB_Connection db = new DB_Connection();
	    Connection conn = db.getConn();
	    DefaultTableModel model = (DefaultTableModel)table.getModel();
	    PreparedStatement pstmt = null;
	 	ResultSet rs = null;
	 	String sql = "select relation, job, names, gender, birth, P.phone "
	 			+ "from person P,family F "
	 			+ "where P.phone = F.phone and F.emp_number = ?"; 
	 	try {
			pstmt = conn.prepareStatement(sql);		
			pstmt.setString(1,emp);
			rs = pstmt.executeQuery();
			int number = 0;
			String relation = "";
			String job = "";
			String names = "";
			String gender = "";
			String birth = "";
			String phone = "";
			while(rs.next())
			{
				number++;
				String num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
				relation = rs.getString(1);
				job = rs.getString(2);
				names = rs.getString(3);
				gender = rs.getString(4);
				birth = rs.getString(5);
				phone = rs.getString(6);
				String[] row = { num_1,relation,job,names,gender,birth,phone};
				 model.addRow(row);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	    
		JButton btnNewButton_1 = new JButton("가족 등록");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				E_f_Regist ef = new E_f_Regist(emp,frame); //frame도 넘겨줘서 새로고침 느낌 기능
			}
		});
		btnNewButton_1.setBounds(97, 316, 257, 32);
		panel.add(btnNewButton_1);
		    
	}
}
