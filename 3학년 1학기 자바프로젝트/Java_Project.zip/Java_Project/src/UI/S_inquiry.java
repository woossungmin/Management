package UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.JRadioButton;

public class S_inquiry {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					S_inquiry window = new S_inquiry();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public S_inquiry() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(300, 120, 718, 512);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 704, 99);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(277, 14, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(277, 14, 146, 23);
		panel.add(progressBar);
	
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				E_inquiry ei = new E_inquiry();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
		
		JLabel lblNewLabel_1 = new JLabel("사번 : ");
		lblNewLabel_1.setBounds(88, 66, 52, 15);
		panel.add(lblNewLabel_1);
		
		JTextField textField = new JTextField();
		textField.setBounds(152, 66, 281, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("등록");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				S_Regist sr = new S_Regist();
			}
		});
		btnNewButton_4.setBounds(544, 53, 62, 40);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_4_1 = new JButton("수정");
		btnNewButton_4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				S_Modify su = new S_Modify();
			}
		});
		btnNewButton_4_1.setBounds(609, 53, 62, 40);
		panel.add(btnNewButton_4_1);
		
		JButton btnNewButton_3 = new JButton("사원 관리");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				E_inquiry ei = new E_inquiry();
			}
		});
		btnNewButton_3.setBounds(600, 425, 95, 39);
		frame.getContentPane().add(btnNewButton_3);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 99, 703, 317);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(2, 0, 702, 317);
		panel_1.add(scrollPane);
		
		ButtonGroup groupRd = new ButtonGroup();
		
		JTable table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"구분","사번", "이름", "연봉", "성과급", "추가근로", "기타수당", "합계"
			}
		));
		scrollPane.setViewportView(table);
		table.getColumn("구분").setPreferredWidth(20);
		table.getColumn("사번").setPreferredWidth(20);
		table.getColumn("이름").setPreferredWidth(40);
		table.getColumn("연봉").setPreferredWidth(40);
		table.getColumn("성과급").setPreferredWidth(40);
		table.getColumn("추가근로").setPreferredWidth(40);
		table.getColumn("기타수당").setPreferredWidth(40);
		table.getColumn("합계").setPreferredWidth(40);
		
		DefaultTableCellRenderer dtcr = new DefaultTableCellRenderer(); //테이블 밑에 사용 튜플값들 가운데 정렬
	    dtcr.setHorizontalAlignment(SwingConstants.CENTER);
	    TableColumnModel tcm = table.getColumnModel();
	    for(int i = 0; i < tcm.getColumnCount(); i++) {
	    	tcm.getColumn(i).setCellRenderer(dtcr);
	    }
	    
	    JButton btnNewButton_1 = new JButton("조회");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField.getText();
				DB_Connection db = new DB_Connection();
				Connection conn = db.getConn();
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				model.setRowCount(0);
				PreparedStatement pstmt = null;
			 	ResultSet rs = null;
			 	String sql = "select S.emp_number,names,basics,bonus,overtime,other "
			 			+ "from salary S,employee E,person P "
			 			+ "where S.emp_number = E.emp_number and E.phone = P.phone and  S.emp_number like '%'+?+'%'";
			 
			 	try {
					pstmt = conn.prepareStatement(sql);		
					pstmt.setString(1,tx);
					rs = pstmt.executeQuery();
					int number = 0;
					String emp_number = "";
					String  name= "";
					String basics = "";
					String bonus = "";
					String overtime = "";
					String other = "";
					String sum = "";
					while(rs.next())
					{
						number++;
						String num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
						emp_number = rs.getString(1);
						name = rs.getString(2);
						basics = rs.getString(3);
						bonus = rs.getString(4);
						overtime = rs.getString(5);
						other = rs.getString(6);
						int basics1 = Integer.parseInt(basics);
						int bonus1 = Integer.parseInt(bonus);
						int overtime1 = Integer.parseInt(overtime);
						int other1 = Integer.parseInt(other);
						int sum1 = basics1 + bonus1 + overtime1 + other1;
						sum = Integer.toString(sum1);
						String[] row = { num_1,emp_number,name,basics,bonus,overtime,other,sum};
						model.addRow(row);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}	
				//String[] row = db.S_inquiry(tx);
			}
		});
		btnNewButton_1.setBounds(445, 55, 87, 18);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("전체 조회");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_Connection db = new DB_Connection();
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				model.setRowCount(0);
				Connection conn = db.getConn();
				PreparedStatement pstmt = null;
			 	ResultSet rs = null;
				PreparedStatement pstmt1 = null;
			 	ResultSet rs1 = null;
			 	String sql = "select E.emp_number,names,basics,bonus,overtime,other from salary S,employee E,person P where S.emp_number=E.emp_number and P.phone = E.phone";
			 	try {
					pstmt = conn.prepareStatement(sql);	
					rs = pstmt.executeQuery();
					int number = 0;
					String emp_number = "";
					String  name= "";
					String basics = "";
					String bonus = "";
					String overtime = "";
					String other = "";
					String sum = "";
					while(rs.next())
					{
						number++;
						String num_1 = Integer.toString(number); // 정수형 -> 문자형으로 형변환
						emp_number = rs.getString(1);
						name = rs.getString(2);
						basics = rs.getString(3);
						bonus = rs.getString(4);
						overtime = rs.getString(5);
						other = rs.getString(6);
						int basics1 = Integer.parseInt(basics);
						int bonus1 = Integer.parseInt(bonus);
						int overtime1 = Integer.parseInt(overtime);
						int other1 = Integer.parseInt(other);
						int sum1 = basics1 + bonus1 + overtime1 + other1;
						sum = Integer.toString(sum1);
						String[] row = { num_1,emp_number,name,basics,bonus,overtime,other,sum};
						model.addRow(row);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1_1.setBounds(445, 74, 87, 18);
		panel.add(btnNewButton_1_1);
		
		JButton btnNewButton_2 = new JButton("초기화");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel)table.getModel();
				model.setRowCount(0);
			}
		});
		btnNewButton_2.setBounds(510, 433, 78, 23);
		frame.getContentPane().add(btnNewButton_2);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setContentAreaFilled(false);
	}
	

}
