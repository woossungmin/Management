package UI;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;

public class S_Modify {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					S_Modify window = new S_Modify();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public S_Modify() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(420, 150, 450, 470);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 436, 433);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});

		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
		
		JTextField textField = new JTextField();
		textField.setBounds(100, 107, 257, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(100, 147, 257, 21);
		panel.add(textField_1);
		
		JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(100, 187, 257, 21);
		panel.add(textField_2);
		
		JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(100, 227, 257, 21);
		panel.add(textField_3);
		
		JTextField textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(100, 267, 257, 21);
		panel.add(textField_4);
		
		JTextField textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(100, 307, 257, 21);
		panel.add(textField_5);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(146, 24, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(146, 24, 146, 23);
		panel.add(progressBar);
		
		JLabel lblNewLabel_1 = new JLabel("사번 : ");
		lblNewLabel_1.setBounds(33, 107, 66, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("이름 : ");
		lblNewLabel_1_1.setBounds(33, 147, 66, 15);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("연봉  : ");
		lblNewLabel_1_2.setBounds(33, 187, 66, 15);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("성과급 : ");
		lblNewLabel_1_3.setBounds(33, 227, 66, 15);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("추가근로 : ");
		lblNewLabel_1_4.setBounds(33, 267, 66, 15);
		panel.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("기타수당 : ");
		lblNewLabel_1_5.setBounds(33, 307, 66, 15);
		panel.add(lblNewLabel_1_5);
		
		JButton btnNewButton_2 = new JButton("초기화");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				textField.setEnabled(true);
			}
		});
		btnNewButton_2.setBounds(185, 400, 86, 23);
		panel.add(btnNewButton_2);
		btnNewButton_2.setBorderPainted(false);
		btnNewButton_2.setContentAreaFilled(false);
		
		JButton btnNewButton_4 = new JButton("조회");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField.getText();
				DB_Connection db = new DB_Connection();
				String[] row = db.S_emp_inquiry1(tx);
				if(row != null)
				{
					Message ms = new Message("존재하는 사원입니다.");
					textField.setEnabled(false);
					textField_1.setText(row[1]);
					textField.setEnabled(false);
					textField_2.setText(row[2]);
					textField_3.setText(row[3]);
					textField_4.setText(row[4]);
					textField_5.setText(row[5]);
				}
				else
				{
					Message ms = new Message("존재하지 않는 사원입니다.");
				}
			}
		});
		btnNewButton_4.setBounds(358, 106, 66, 23);
		panel.add(btnNewButton_4);
		
		JButton btnNewButton_1 = new JButton("연봉 수정");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DB_Connection db = new DB_Connection();
				
				String tx = textField.getText();
				String tx2 = textField_2.getText();
				String tx3 = textField_3.getText();
				String tx4 = textField_4.getText();
				String tx5 = textField_5.getText();
				int result = db.S_update(tx2, tx3, tx4, tx5,tx);
				if(result == 1)
				{
					Message ms = new Message("수정 완료");
					frame.dispose();
				}
			}
		});
		btnNewButton_1.setBounds(100, 365, 257, 32);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("초기화");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				textField.setEnabled(true);
			}
		});
		btnNewButton_3.setBounds(185, 400, 86, 23);
		panel.add(btnNewButton_3);
		btnNewButton_3.setBorderPainted(false);
		btnNewButton_3.setContentAreaFilled(false);
	}

}
