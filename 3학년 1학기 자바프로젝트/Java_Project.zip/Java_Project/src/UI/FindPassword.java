package UI;

import static javax.swing.JOptionPane.showMessageDialog;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;

public class FindPassword {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FindPassword window = new FindPassword();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FindPassword() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(420, 150, 450, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.setResizable(false);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 436, 413);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("S&M Company");
		lblNewLabel.setBounds(146, 24, 146, 23);
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(JLabel.CENTER);
		
		JProgressBar progressBar = new JProgressBar();
		progressBar.setBounds(146, 24, 146, 23);
		panel.add(progressBar);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				Login lo = new Login();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\user\\Desktop\\back.png"));
		btnNewButton.setBounds(0, 0, 45, 37);
		panel.add(btnNewButton);
		btnNewButton.setBorderPainted(false);
		btnNewButton.setContentAreaFilled(false);
		
		JTextField textField = new JTextField();
		textField.setBounds(100, 150, 257, 21);
		panel.add(textField);
		textField.setColumns(10);
		
		JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(100, 210, 257, 21);
		panel.add(textField_1);
		
		JLabel lblNewLabel_1 = new JLabel("사번 : ");
		lblNewLabel_1.setBounds(33, 150, 66, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("전화번호 : ");
		lblNewLabel_1_1.setBounds(33, 210, 66, 15);
		panel.add(lblNewLabel_1_1);
		
		JButton btnNewButton_1 = new JButton("비밀번호 찾기");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String tx = textField.getText();
				String tx_1 = textField_1.getText();
				DB_Connection db = new DB_Connection();
				String pw = db.find_pw(tx, tx_1);
				Message ms = new Message(pw);
				frame.dispose();
				Login lo = new Login();
			}
		});
		btnNewButton_1.setBounds(100, 270, 257, 32);
		panel.add(btnNewButton_1);
	}

}
